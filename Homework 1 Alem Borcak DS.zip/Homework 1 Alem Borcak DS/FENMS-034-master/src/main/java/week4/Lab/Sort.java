package week4.Lab;

public class Sort extends AbstractSort{

    public static void selectionSort(int[] elements){
        for (int i = 0; i < elements.length; i++){
            int min = i;
            for(int j = i + 1; j < elements.length; j++){
                if(less(elements[j], elements[min])){
                    min = j;
                }
            }
            swap(elements, i, min);
        }
    }

    // Generic Version
    /*public static <Data extends Comparable<Data>>void selectionSortV2(int[] elements){
        for (int i = 0; i < elements.length; i++){
            int min = i;
            for(int j = i + 1; j < elements.length; j++){
                if(lessV2(elements[j], elements[min])){
                    min = j;
                }
            }
            swapV2(elements, i, min);
        }
    }
     */

    public static void insertionSort(int[] elements){
        for(int i = 0; i < elements.length; i++){
            for(int j = i; j > 0; j--){
                if (less(elements[j], elements[j - 1])){
                    swap(elements, j, j - 1);
            } else{
                    break;
                }
            }
        }
    }

    // variation of insertion sort, work across larger gaps(stride - h = 1) between elements
    // h - sorting; 3h + 1 (1, 4, 13, 40, ...)
    public static void shellSort(int[] elements){
        int h = 1;
        while(h < elements.length / 3){
            h = 3 * h + 1;
            //System.out.println(h);
        }

        while (h >= 1){
            for (int i = h; i < elements.length; i++){
                for(int j = i; j >= h; j -= h){
                    if(less(elements[j], elements[j - h])){
                        swap(elements, j, j - h);
                    }
                }
            }
            h = h / 3;
        }
    }
}
