package week4.Lab;

import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //int[] array = {5, 8, -1, 2, 7, 4, 1};

        /*Sort.selectionSort(array);

        for (int i: array){
            System.out.print(i + " ");
        }
    }*/

        //int[] array = new int[100];
        /*Sort.shellSort(array);

        for (int i : array) {
            System.out.print(i + " ");
        }*/

        int size = 100;
        int[] array = new int[size];
        Random random = new Random();

        for(int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(size);
        }

        long start = System.currentTimeMillis();
        Sort.shellSort(array);
        System.out.println(System.currentTimeMillis() - start);
    }
}
