package week4.Lab;

public abstract class AbstractSort { // to be able to simply pass it in the other functions

    public static boolean less(int a, int b){
        return a < b;
    }

    // Generic Version
    public static <Data extends Comparable<Data>> boolean lessV2(Data a, Data b){
        return a.compareTo(b) < 0;
    }

    public static void swap(int[] elements, int i, int j){
        int temp = elements[i];
        elements[i] = elements[j];
        elements[j] = temp;
    }

    // Generic Version
    // To use generics we have to change int to Integer

    /*public static <Data extends Comparable<Data>> void swapV2(int[] elements, int i, int j){
        Data temp = elements[i];
        elements[i] = elements[j];
        elements[j] = temp;
    }*/
}
