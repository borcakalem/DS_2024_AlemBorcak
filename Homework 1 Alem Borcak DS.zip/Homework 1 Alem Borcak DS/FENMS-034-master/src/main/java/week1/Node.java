package week1;

public class Node <Data>{
    Data data;
    Node<Data> next;
}