package week1;

import java.util.Iterator;

public class DoublyLinkedList<Data> implements Iterable<Data> {
    private DoubleNode<Data> head;
    private DoubleNode<Data> tail;
    private int size = 0;

    /* Add a new node to the front of the doubly linked list */
    public void addToFront(Data data) {
        DoubleNode<Data> newNode = new DoubleNode<>();
        newNode.data = data;

        if (head == null){
            head = newNode;
            tail = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode; //.prev is used for Doubly Linked List
        }                             // because the reference goes back and front
        size++;
    }

    /* Remove a node from the front of the doubly linked list */
    public void removeFromFront() {
        if (head == null){
            throw new IndexOutOfBoundsException("The linked list is empty.");
        }
        head = head.next;
        head.prev = null;
        size--;
    }

    /* Add a new node to the end of the doubly linked list */
    public void addToRear(Data data) {
        DoubleNode<Data> newNode = new DoubleNode<>();
        newNode.data = data;
        if (head == null){
            head = newNode;
        } else {
            DoubleNode<Data> current = head;
            while (current.next != null){
                current = current.next;
            }
            newNode.prev = current;
            tail = newNode;
            current.next = newNode;
        }
        size++;
    }

    /* Remove a node at the end of the doubly linked list */
    public void removeFromRear() {
        if (head == null){
            throw new IndexOutOfBoundsException("The linked list is empty.");
        } else if (size == 1){
            head = null;
        } else{
            DoubleNode<Data> current = head;
            while (current.next.next != null){
                current = current.next;
            }
            current.next = null;
        }
        size--;
    }

    /* Get a linked list node by index (0-indexed) */
    public Data get(int index) {
        if (index < 0 || index >= size){
            throw new IndexOutOfBoundsException("Invalid index value.");
        }
        DoubleNode<Data> current = head;
        if (index != 0){
            int i = 0;
            while (i < index){
                current = current.next;
                i++;
            }
        }
        return current.data;
    }

    /* Add an element to a doubly linked list by index (0-index) */
    public void add(int index, Data data) {
        if (index < 0 || index >= size){
            throw new IndexOutOfBoundsException("Invalid linked list node.");
        }
        DoubleNode<Data> newNode = new DoubleNode<>();
        newNode.data = data;

        DoubleNode<Data> current = head;
        DoubleNode<Data> temp = new DoubleNode<>();
        int i = 0;
        while (i < index){
            temp = current;
            current = current.next;
            i++;
        }

        newNode.next = current;
        newNode.prev = current.prev;
        temp.next = newNode;
        size++;
    }

    /* Delete an element from a doubly linked list by index (0-index) */
    public void remove(int index) {
        if (index < 0 || index >= size){
            throw new IndexOutOfBoundsException("Invalid linked list node.");
        }
        DoubleNode<Data> current = head;
        DoubleNode<Data> previous = new DoubleNode<>();
        int i = 0;
        while(i < index){
            previous = current;
            current = current.next;
            i++;
        }
        previous.next = current.next;
        current.next.prev = previous;
        size++;
    }

    /* Return the current size of the doubly linked list */
    public int count() {
        return size; // count should return the size
    }

    /* Return an Iterator Object */
    @Override
    public Iterator<Data> iterator() {
        return new DoublyLinkedListIterator();
    }

    /* Define the Iterator class, and hasNext() and next() methods */
    private class DoublyLinkedListIterator implements Iterator<Data> {
        DoubleNode<Data> current = head;

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public Data next() {
            Data data = current.data;
            current = current.next;
            return data;
        }
    }

    /* Get head node (for test purposes) */
    public DoubleNode<Data> getHead() {
        return head;
    }

    /* Get tail node (for test purposes) */
    public DoubleNode<Data> getTail() {
        return tail;
    }
}