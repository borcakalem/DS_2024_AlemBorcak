package week3.Lab;

public class Search {
    public static int linearSearch(int[] elements, int key){
        for(int i = 0; i < elements.length; i++){
            if (elements[i] == key){
                return i;
            }
        }
        return -1;
    }
    public static int binarySearch(int[] elements, int key){
        int low = 0;
        int high = elements.length - 1;

        while(low <= high){
            int mid = low + (high - low) / 2;
             if(elements[mid] == key){
                 return mid;
             } else if(elements[mid] < key){
                 low = mid + 1;
             } else{
                 high = mid - 1;
             }
        }
        return -1;
    }
}
