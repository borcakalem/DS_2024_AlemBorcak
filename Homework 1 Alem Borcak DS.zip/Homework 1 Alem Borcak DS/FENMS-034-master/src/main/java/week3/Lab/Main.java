package week3.Lab;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        // Linear Search

        int[] elements = {2, 1, -3, 8, 7, 6, 12};

        int index = Search.linearSearch(elements, 7);
        System.out.println("Index: " + index);

        index = Search.linearSearch(elements, 10);
        System.out.println("Index:" + index);



        // Binary Search

        int[] elements2 = {-3, 1, 2, 6, 7, 8, 12};

        index = Search.binarySearch(elements2, 7);
        System.out.println("Index: " + index);


        // Binary Search using sort method
        Arrays.sort(elements);

        index = Search.binarySearch(elements, 10);
        System.out.println("Index: " + index);

        // Bubble Sort
        //Sort.bubbleSort(elements);
        for(int i: elements){
            System.out.println(i);
        }

        Student[] students = {
                new Student(5.6),
                new Student(7.5),
                new Student(8.3),
                new Student(9.2),
                new Student(6.6),
        };

        Arrays.sort(students);

        Sort.bubbleSort(students);
        for (Student s: students){
            System.out.println(s.gpa);
        }
    }
}
