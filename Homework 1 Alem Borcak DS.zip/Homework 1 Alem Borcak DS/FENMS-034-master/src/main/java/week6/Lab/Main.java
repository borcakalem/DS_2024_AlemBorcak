package week6.Lab;

public class Main {
    public static void main(String[] args) {
        int[] array = {5, 2, -1, 8, 3, 9, 10, 11, 7};

        Sort.quickSort(array);

        for(int i: array){
            System.out.println(i);
        }

        // do the test for test secs in Mills
        /*int size = 100000;
        * int[] array = new int[size];
        *
        * Random random = new Random();
        * for (int i = 0; i < size; i++){
        *   array[i] = random.nextInt(size);
        * }
        *
        * long start = System.TumeMills();*/
    }
}
