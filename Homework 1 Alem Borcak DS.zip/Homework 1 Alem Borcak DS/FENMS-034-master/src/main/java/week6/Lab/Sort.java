package week6.Lab;

import java.util.Random;

public class Sort { // extend abstract sort or make a swap
    public static void quickSort(int[] elements){
        shuffle(elements);
        sort(elements, 0, elements.length - 1);// to work recursivly
    }

    private static void shuffle(int[] elements){
        Random random = new Random();
        for (int i = 0; i <elements.length; i++){
            int r = i + random.nextInt(elements.length - i); // random integer
            swap(elements, i, r);
        }
    }

    private static void swap(int[] elements, int i, int j){
        int temp = elements[i];
        elements[i] = elements[j];
        elements[j] = temp;
    }

    private static void sort(int[] elements, int low, int high){
        if (high <= low){ // same thing used in Merge Sort
            return;
        }
        int p = partition(elements, low, high);
        sort(elements, low, p - 1);
        sort(elements, p + 1, high);
    }

    private static int partition(int[] elements, int low, int high){
        int i = low;
        int j = high + 1;

        while(true){
            while(elements[++i] < elements[low]){ // low is the pivit element
                if(i == high){
                    break;
                }
            }

            while (elements[--j] >= elements[low]){ // low is the pivit element
                if(j == low){
                    break;
                }
            }
            if(j <= i){ // if they are crossed then we break
                break;
            }
            swap(elements, i, j); // we don't have to do the swap if the elements have already crossed
        }
        swap(elements, j, low);
        return j; // value of the pivit
    }
}
