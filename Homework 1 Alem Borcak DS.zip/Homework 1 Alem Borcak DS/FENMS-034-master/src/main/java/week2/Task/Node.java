package week2.Task;

public class Node<Data> {
    Data data;
    Node<Data> next;
}
