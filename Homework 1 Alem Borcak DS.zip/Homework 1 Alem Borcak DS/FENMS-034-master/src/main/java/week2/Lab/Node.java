package week2.Lab;

public class Node<Data> {
    Data data;
    Node<Data> next;
}
