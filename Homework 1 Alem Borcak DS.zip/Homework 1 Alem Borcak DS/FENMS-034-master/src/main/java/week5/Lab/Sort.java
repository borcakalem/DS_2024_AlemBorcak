package week5.Lab;

import week4.Lab.AbstractSort;

import static week4.Lab.AbstractSort.less;

public class Sort extends AbstractSort {
    /* Merge sort algorithm (public invocation) */
    public static void mergeSort(int[] elements) {
        int[] aux = new int[elements.length]; //temp, help
        sort(elements, aux, 0, elements.length - 1); // on entire array
    }

    private static void sort(int[] elements, int[] aux, int low, int high) {
        if (high <= low) { // < because of the mid condition
            return;
        }

        int mid = low + (high - low) / 2; // mid can calculate high to be equal to 1 less than low

        sort(elements, aux, low, mid); // recursively sorts the first half
        sort(elements, aux, mid + 1, high); // recursively sorts the second half

        merge(elements, aux, low, mid, high); // merges first and second half
    }

    /* Merge the two sorted sub-arrays into a larger sorted (sub)array */
    private static void merge(int[] elements, int[] aux, int low, int mid, int high){
        for (int k = low; k <= high; k++) {             // 1
            aux[k] = elements[k];                       // 1
        }

        int i = low;                                    // 2
        int j = mid + 1;                                // 2
        for (int k = low; k <= high; k++) {             // 3
            if (i > mid) {                              // 4
                elements[k] = aux[j++];                 // 4
            } else if (j > high) {                      // 5
                elements[k] = aux[i++];                 // 5
            } else if (less(aux[j], aux[i])) {          // 6
                elements[k] = aux[j++];                 // 6
            } else {                                    // 7
                elements[k] = aux[i++];                 // 7
            }
        }
    }
}
