package homework1;

public class BinarySearch {

    public static int[] search(Entry[] entries, String searchableName) {
        int firstIndex = findFirstIndex(entries, searchableName);
        if (firstIndex == -1) {
            return new int[] {}; // No match found
        }

        int lastIndex = findLastIndex(entries, searchableName);
        return new int[] {firstIndex, lastIndex};
    }

    private static int findFirstIndex(Entry[] entries, String searchableName) {
        int low = 0;
        int high = entries.length - 1;
        int result = -1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (entries[mid].getName().compareTo(searchableName) >= 0) {
                if (entries[mid].getName().compareTo(searchableName) == 0) {
                    result = mid;
                }
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }
        return result;
    }

    private static int findLastIndex(Entry[] entries, String searchableName) {
        int low = 0;
        int high = entries.length - 1;
        int result = -1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (entries[mid].getName().compareTo(searchableName) <= 0) {
                if (entries[mid].getName().compareTo(searchableName) == 0) {
                    result = mid;
                }
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return result;
    }
}
