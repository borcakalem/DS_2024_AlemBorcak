package homework1;

import java.util.Comparator;

public class EntryComparators {

    public static class NameComparator implements Comparator<Entry> {
        @Override
        public int compare(Entry e1, Entry e2) {
            return e1.getName().compareTo(e2.getName());
        }
    }

    public static class StreetAddressComparator implements Comparator<Entry> {
        @Override
        public int compare(Entry e1, Entry e2) {
            return e1.getStreetAddress().compareTo(e2.getStreetAddress());
        }
    }

    public static class CityComparator implements Comparator<Entry> {
        @Override
        public int compare(Entry e1, Entry e2) {
            return e1.getCity().compareTo(e2.getCity());
        }
    }

    public static class PostcodeComparator implements Comparator<Entry> {
        @Override
        public int compare(Entry e1, Entry e2) {
            return e1.getPostcode().compareTo(e2.getPostcode());
        }
    }

    public static class CountryComparator implements Comparator<Entry> {
        @Override
        public int compare(Entry e1, Entry e2) {
            return e1.getCountry().compareTo(e2.getCountry());
        }
    }

    public static class PhoneNumberComparator implements Comparator<Entry> {
        @Override
        public int compare(Entry e1, Entry e2) {
            return e1.getPhoneNumber().compareTo(e2.getPhoneNumber());
        }
    }
}
