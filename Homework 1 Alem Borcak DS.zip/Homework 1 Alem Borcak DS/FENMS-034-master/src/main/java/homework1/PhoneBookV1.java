package homework1;

import java.util.Scanner;

public class PhoneBookV1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // File paths
        String inputFilePath = "C:\\Users\\selma\\OneDrive\\Dokumenti\\DS\\raw_phonebook_data.csv";
        String outputFilePath = "C:\\Users\\selma\\OneDrive\\Dokumenti\\DS\\output.csv";

        // Step 1: Load the unsorted file into an array
        System.out.println("Loading the entries...");
        Entry[] entries = FileUtils.readFile(inputFilePath);

        // Step 2: Sort the array using merge sort with NameComparator
        System.out.println("Sorting the entries...");
        MergeSort.sort(entries, new EntryComparators.NameComparator());

        // Step 3: Save the sorted array into a new CSV file
        System.out.println("Saving the sorted file...");
        FileUtils.writeToFile(entries, outputFilePath);
        System.out.println("=======================");
        System.out.println("System is ready.");

        // Step 4: Prompt user for search queries
        while (true) {
            System.out.print("\nEnter the name that you wish to search for, or -1 to exit: ");
            String input = scanner.nextLine();

            if (input.equals("-1")) {
                System.out.println("Thank you for using the phonebook.");
                break;
            }

            // Step 5: Perform binary search
            int[] result = BinarySearch.search(entries, input);

            // Step 6: Display search results
            if (result.length == 0) {
                System.out.println("No entries with the given name exist in the phonebook.");
            } else {
                int start = result[0];
                int end = result[1];
                System.out.println("Entries found: " + (end - start + 1));
                for (int i = start; i <= end; i++) {
                    Entry entry = entries[i];
                    System.out.println();
                    System.out.println("Name: " + entry.getName());
                    System.out.println("Street address: " + entry.getStreetAddress());
                    System.out.println("City: " + entry.getCity());
                    System.out.println("Postal code: " + entry.getPostcode());
                    System.out.println("Country: " + entry.getCountry());
                    System.out.println("Phone number: " + entry.getPhoneNumber());
                }
            }
        }

        scanner.close();
    }
}
